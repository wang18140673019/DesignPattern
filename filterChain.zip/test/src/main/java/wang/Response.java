package wang;
//封装响应信息的类Response
public class Response {
    public String responseStr;

    public String getResponse() {
        return responseStr;
    }

    public void setResponse(String response) {
        this.responseStr = response;
    }
    
}